from rest_framework.response import Response
from rest_framework import status
from rest_framework import viewsets
from django.http import JsonResponse
from .models import *
from .serializers import*
# Create your views here.

class GetMethod(viewsets.ModelViewSet):
    queryset = FoodDonation.objects.all()
    serializer_class = FoodDonationSerializer

    def list(self, request, *args, **kwargs):
        data = list(FoodDonation.objects.all().values())
        return Response(data)

    def retrieve(self, request, *args, **kwargs):
        data = list(FoodDonation.objects.filter(id=kwargs['pk']).values())
        return Response(data)

    def create(self, request, *args, **kwargs):
        FoodDonation_serializer_data = FoodDonationSerializer(data=request.data)
        if FoodDonation_serializer_data.is_valid():
            FoodDonation_serializer_data.save()
            status_code = status.HTTP_201_CREATED
            return Response({"message": "Added Sucessfully", "status": status_code})
        else:
            status_code = status.HTTP_400_BAD_REQUEST
            return Response({"message": "please fill all fields", "status": status_code})

    def destroy(self, request, *args, **kwargs):
        FoodDonation_data = FoodDonation.objects.filter(id=kwargs['pk'])
        if FoodDonation_data:
            FoodDonation_data.delete()
            status_code = status.HTTP_201_CREATED
            return Response({"message": "delete Sucessfully", "status": status_code})
        else:
            status_code = status.HTTP_400_BAD_REQUEST
            return Response({"message": "data not found", "status": status_code})

