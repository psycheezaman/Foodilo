from rest_framework import serializers
from .models  import*

class FoodDonationSerializer(serializers.ModelSerializer):
    class Meta():
        model = FoodDonation
        fields = "__all__"