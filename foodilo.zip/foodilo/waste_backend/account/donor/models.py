from django.db import models

class FoodDonation(models.Model):
    donor_name = models.CharField(max_length=100)
    location = models.CharField(max_length=200)
    phone_number = models.CharField(max_length=15)  # Assuming a standard international format
    food_item = models.CharField(max_length=100)
    amount_of_food = models.CharField(max_length=100)  # Assuming the amount is in units (grams, kilograms, etc.)
    timestamp = models.DateTimeField(auto_now_add=True)
