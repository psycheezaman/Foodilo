package com.example.food_reduction;

public interface Activity {
    void onCreate();

    void onCreate(Bundle savedInstanceState);

    boolean onCreateOptionsMenu(Menu menu);

    boolean onSupportNavigateup();
}
