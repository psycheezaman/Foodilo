import 'package:flutter/material.dart';

        void main() {
        runApp(FoodWasteReductionApp());
        }

class FoodWasteReductionApp extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
        return MaterialApp(
                title: 'Food Waste Reduction',
                theme: ThemeData(
                primarySwatch: Colors.green,
                visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
        home: HomePage(),
    );
    }
}

class HomePage extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
        return Scaffold(
                appBar: AppBar(
                title: Text('Food Wastage Reduction'),
      ),
        body: Center(
                child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
        Text(
                'Food Wastage Reduction',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        textAlign: TextAlign.center,
            ),
        SizedBox(height: 20),
        Text(
                'Together, let\'s make a difference!',
                style: TextStyle(fontSize: 16),
        textAlign: TextAlign.center,
            ),
        SizedBox(height: 40),
        ElevatedButton(
                onPressed: () {
            // Navigate to your feature screen or functionality
        },
        child: Text('Get Started'),
            ),
          ],
        ),
      ),
    );
    }
}
