package com.example.food_reduction;

public class MainActivityApp extends MainActivity {
}
